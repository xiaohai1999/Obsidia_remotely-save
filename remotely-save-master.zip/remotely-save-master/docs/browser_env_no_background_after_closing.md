# Limitations From The Browser Environment: No Background Running After Obsidian Is Closed

The plugin treats Obsidian as a special browser, and is in fact some js codes. So if Obsidian is closed, then the browser environment stops, then the plugin will be stopped.
