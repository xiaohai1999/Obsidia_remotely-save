export let Buffer = require("buffer").Buffer;
export let process = require("process/browser");
